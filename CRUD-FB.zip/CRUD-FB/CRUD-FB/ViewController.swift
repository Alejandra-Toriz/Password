//
//  ViewController.swift
//  CRUD-FB
//
//  Created by Germán Santos Jaimes on 11/4/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
//Se hace un outlet de la tabla sin necesidad de arrastrar y soltar del
    @IBOutlet weak var TablaEmpleados: UITableView!
    //Arreglo de empleados
    private var listaEmpleados = [Employee]()
    
    //especie de apuntador al archivo
    var employeeCollectionRef : CollectionReference! //tengo la referencia de los datos ! "aguanta vara le aseguro que usaré un inicializador pero no lo construyo" ? "puede ser me obliga a un constructor/inicializador"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //PARA Crear un oulet sin arrastrar y soltar
        //Quien sera el delegado?   yo
        TablaEmpleados.delegate = self
        //Quien me da los datos?     yo
        TablaEmpleados.dataSource = self
        
        var empleado = Employee(firstName: "German", lastName: "SAntos", salary: 400.0)
        listaEmpleados.append(empleado)
        
        //Para usarlo bien se una en viewDidLoad
        employeeCollectionRef = Firestore.firestore().collection("employee")
        
    }
    
    //SUPONIENDO QUE HAY DATOS EN FIREBASE
    /*Los datos de meten aqui en vez de ViewDidLoad por que:
    viewDidLoad: ya se cargo la vista??, no sirve para actualizar la vista porque YA SE PINTO!
    viewWillAppear: sirve para que se refresque la vista cuando YA esta pintada (mas no pintar)
 */
    override func viewWillAppear(_ animated: Bool) {
        //De la coleccion employee dame todos los documentos/ registros que tengas
       
        employeeCollectionRef.getDocuments { (snapshot, error) in
            if let error = error{
                debugPrint(error)//Si  hay un error dime
            }else{
                //esta linea inicializa la lista para no estar borrando y copiando
                self.listaEmpleados.removeAll()
                
                //Itera sobre cada documento
                for document in (snapshot?.documents)!{
                    // paso 1
                    //print(document.data())
                    
                    // paso 2
                    let data = document.data()//dame os datos los regresa tipo Any
                    let firstname = data["firstName"] as! String //Casteo
                    let lastname = data["lastName"] as! String //Casteo
                    let salary = data["salary"] as? Double ?? 0.00 //o inicializalo si no devuelve nad
                    let timestamp = data["timestamp"] as! Date ?? Date()
                    let documentId = document.documentID //Dame el ID del docume to
                    
                    //Unavez que obtengo datos creo un emplead0o con ellos
                    let newEmployee = Employee(firstName: firstname, lastName: lastname, salary: salary)
                    //depues lo agrego a la lista de empleados
                    self.listaEmpleados.append(newEmployee)
                }
                 self.TablaEmpleados.reloadData()//tabla refrescate
            }
            
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaEmpleados.count
    }
    
    //Para traer datos
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Igual creo una  celda reutilizable
        if let cell = TablaEmpleados.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? EmployeeCell{
            
            //configureCell ayuda a  erificar que existan datos en el arreglo, si no hay nada regresa una celda vacia y no un nulo (asi no truena)
            cell.configureCell(employee: listaEmpleados[indexPath.row])
            return cell
        }else{
            return UITableViewCell()
        }
    }

}

