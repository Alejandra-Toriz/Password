//
//  AddEmployeeVC.swift
//  CRUD-FB
//
//  Created by Germán Santos Jaimes on 11/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class AddEmployeeVC: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var salary: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
 //Este boton obtiene los datos en los text field
    @IBAction func addEmployee(_ sender: UIButton) {
        let nombre = firstName.text //Campos de firebase
        let apellidos = lastName.text
        let salario = salary.text
        let tiempo = FieldValue.serverTimestamp()//obtiene fecha de creación
        
        Firestore.firestore().collection("employee").addDocument(data: ["firstName": nombre, "lastName": apellidos, "salary": salario, "timestamp": tiempo]) { (error) in
            if let error = error{
                debugPrint(error) //imprime el error
            }else{
                //de lo contrario funcionamientlo de pilas
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    //Si se cansela se retira la vista igual como pila
    @IBAction func cancel(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
}
